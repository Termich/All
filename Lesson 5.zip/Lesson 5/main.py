from First import create
from Third import special
from Second import kill


# Ввод функции из первого документа
create('dir',range)

# Вычисление случайного числа из модуля Second
special

#Удаляем папки
kill




